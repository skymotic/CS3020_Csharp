﻿using System;
using Microsoft.VisualBasic.FileIO;
using System.IO;
using System.Collections.Generic;

namespace LinkQChallenge6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Band> bands = new List<Band>();

            TextFieldParser parser = new TextFieldParser("metal_bands_2017.csv");
            parser.Delimiters = new string[] { "," };
            while (true)
            {
                string[] parts = parser.ReadFields();
                if (parts == null)
                {
                    break;
                }
                bands.Add(new Band(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]));
            }

            foreach(Band cc in bands)
            {
                Console.WriteLine(cc.ToString());
            }
        }
    }
}
